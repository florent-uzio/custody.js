import { Currency } from '../common'

import { BaseRequest, BaseResponse } from './baseMethod'

/**
 * The `vault_info` method gets information about a Vault instance.
 * Returns an {@link VaultInfoResponse}.
 *
 * @category Requests
 */
export interface VaultInfoRequest extends BaseRequest {
  command: 'vault_info'

  /**
   * The object ID of the Vault to be returned.
   */
  vault_id?: string

  /**
   * ID of the Vault Owner account.
   */
  owner?: string

  /**
   * Sequence number of the vault entry.
   */
  seq?: number
}

/**
 * Response expected from an {@link VaultInfoRequest}.
 *
 * @category Responses
 */
export interface VaultInfoResponse extends BaseResponse {
  result: {
    vault: {
      /**
       * The pseudo-account ID of the vault.
       */
      Account: string

      /**
       * Object representing the asset held in the vault.
       */
      Asset: Currency

      /**
       * Amount of assets currently available for withdrawal.
       */
      AssetsAvailable?: string

      /**
       * Total amount of assets in the vault.
       */
      AssetsTotal?: string

      /**
       * Ledger entry type, always "Vault".
       */
      LedgerEntryType: 'Vault'

      /**
       * ID of the Vault Owner account.
       */
      Owner: string

      /**
       * Transaction ID of the last modification to this vault.
       */
      PreviousTxnID: string

      /**
       * Ledger sequence number of the last transaction modifying this vault.
       */
      PreviousTxnLgrSeq: number

      /**
       * Sequence number of the vault entry.
       */
      Sequence: number

      /**
       * Unique index of the vault ledger entry.
       */
      index: string

      /**
       * Object containing details about issued shares.
       */
      shares: {
        /**
         * The ID of the Issuer of the Share. It will always be the pseudo-account ID.
         */
        Issuer: string

        /**
         * Ledger entry type, always "MPTokenIssuance".
         */
        LedgerEntryType: string

        /**
         * Total outstanding shares issued.
         */
        OutstandingAmount: string

        /**
         * Transaction ID of the last modification to the shares issuance.
         */
        PreviousTxnID: string

        /**
         * Ledger sequence number of the last transaction modifying the shares issuance.
         */
        PreviousTxnLgrSeq: number

        /**
         * Sequence number of the shares issuance entry.
         */
        Sequence: number

        /**
         * Unique index of the shares ledger entry.
         */
        index: string

        /**
         * Identifier for the owner node of the shares.
         */
        OwnerNode: string

        /**
         * The ID of the MPTokenIssuance object. It will always be equal to vault.ShareMPTID.
         */
        mpt_issuance_id?: string

        /**
         * The PermissionedDomain object ID associated with the shares of this Vault.
         */
        DomainID?: string

        /**
         * Bit-field flags associated with the shares issuance.
         */
        Flags: number

        /**
         * An asset scale is a non-negative integer (0, 1, 2, ...)
         * such that one MPT unit equals 10^(-scale) of a
         * corresponding standard unit.
         */
        AssetScale?: number

        /**
         * An unsigned 64-bit number that specifies the maximum
         * number of MPTs that can be distributed to non-issuing
         * accounts (i.e., minted).
         */
        MaximumAmount?: string

        /**
         * This value specifies the fee, in tenths of a basis
         * point, charged by the issuer for secondary sales of the
         * token. Valid values are between 0 and 50,000 inclusive.
         */
        TransferFee?: number

        /**
         * Arbitrary metadata about this issuance, in hex format.
         * The limit for this field is 1024 bytes.
         */
        MPTokenMetadata?: string

        /**
         * The total amount of this MPT that is currently locked
         * across all holders via Escrow or PaymentChannel.
         */
        LockedAmount?: string

        /**
         * Hash256 pointing to the vault pseudo-account's holding for the
         * underlying asset. Present for IOU and MPT-backed vaults.
         * Absent for XRP-backed vaults.
         */
        ReferenceHolding?: string
      }

      /**
       * Unrealized loss associated with the vault.
       */
      LossUnrealized?: string

      /**
       * Identifier for the owner node in the ledger tree.
       */
      OwnerNode: string

      /**
       * Multi-purpose token ID associated with this vault.
       */
      ShareMPTID: string

      /**
       * Policy defining withdrawal conditions.
       */
      WithdrawalPolicy: number

      /**
       * The maximum asset amount that can be held in the vault. Zero value indicates there is no cap.
       */
      AssetsMaximum?: string

      /**
       * Arbitrary metadata about the Vault. Limited to 256 bytes.
       */
      Data?: string

      /**
       * The scaling factor for vault shares. Only applicable for IOU assets.
       * Valid values are between 0 and 18 inclusive. For XRP and MPT, this is always 0.
       */
      Scale?: number

      /**
       * Flags
       */
      Flags: number
    }

    /**
     * The identifying hash of the ledger that was used to generate this
     * response.
     */
    ledger_hash?: string

    /**
     * The ledger index of the ledger version that was used to generate this
     * response.
     */
    ledger_index?: number

    /**
     * The ledger index of the current in-progress ledger, which was used when
     * retrieving this information. May be omitted.
     */
    ledger_current_index?: number

    /**
     * If included and set to true, the information in this response comes from
     * a validated ledger version. Otherwise, the information is subject to
     * change.
     */
    validated?: boolean
  }
}
